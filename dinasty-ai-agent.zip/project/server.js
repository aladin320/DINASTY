import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '1mb' }));

// Serve the DINASTY frontend (index.html, style.css, script.js) from the
// same origin as the API, so the browser's fetch('/api/agent-chat') in
// script.js just works — no CORS setup needed.
app.use(express.static(path.join(__dirname, 'public')));

const MODEL = 'claude-opus-5'; // more capable than Sonnet — better reasoning, nuance, and judgment for open-ended questions
const MAX_TURNS = 20; // cap how much history we forward, per request

const SYSTEM_PROMPT = `You are the DINASTY Guide, an assistant embedded in the DINASTY website — an AI tool discovery platform for software teams. Answer whatever the person actually asks, as helpfully and directly as a knowledgeable assistant would — don't limit yourself to platform questions or redirect people away from what they asked.

Think before you answer. Don't default to the shortest possible reply — match the depth of your answer to the question: a quick factual question gets a quick answer, but a real question deserving explanation, comparison, or judgment gets one, with the reasoning shown, not just a conclusion. If a question is ambiguous, ask what they mean rather than guessing. If you're not sure about something, say so instead of making it up. Keep it conversational, not a wall of text — but don't sacrifice substance for brevity.

You have specific, accurate knowledge of this platform, and should use it whenever it's relevant to what's being asked — reference the actual UI by name so people know exactly what to click:
- Goal-based AI picker: category cards on the home page (Writing, Image Generation, Video, Music, Coding, Productivity, Education, Research, Marketing, Business, Automation, Voice, Design). Clicking a card, or the "Sign in" button in the nav, opens a modal that jumps straight to the single best-fit AI tool for that goal, with a plain explanation of how it works and why it's the pick. From there people can search or browse the full catalog of 42 AI tools.
- Performance reviews: inside each AI's detail view in that same modal there's a "Performance reviews" section — an average star rating and comments from people who've actually used that tool, plus a form to leave a new star rating and comment.
- Community section: people click "Share your project" to post something they built with AI (a title, which AI they used, a description, and an optional link). Every shared project has its own comment thread so others can react to the work.
- Request a quote: a button in the top navigation (and in the Product section) opens a form asking for name, company, contact details, the service they want AI for, and a project title; submitting it sends a quote request to the team.

For anything outside that — general questions, advice, technical problems, whatever the person brings up — just answer normally and honestly, the way you would in any other conversation. Never invent DINASTY features that aren't listed above, but don't restrict the conversation to DINASTY topics only.`;

app.post('/api/agent-chat', async (req, res) => {
  try {
    const { messages } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array is required' });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      // No key yet — don't hard-fail. Answer with a real reply so the chat
      // UI (bubbles, typing indicator, multi-turn) is fully verifiable the
      // moment someone runs `npm start`, before they've added a key.
      console.warn('ANTHROPIC_API_KEY not set — replying in demo mode. See .env.example.');
      return res.json({
        reply: "I'm running in demo mode right now because no ANTHROPIC_API_KEY is set on the server yet — add one to your .env file (see .env.example) and restart the server to get real, tailored answers from Claude. Once that's done, ask me anything about finding the right AI, performance reviews, the Community section, or requesting a quote."
      });
    }

    // Only forward well-formed turns, and cap how far back we go.
    const trimmed = messages
      .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-MAX_TURNS);

    if (trimmed.length === 0) {
      return res.status(400).json({ error: 'messages array had no valid turns' });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 900,
        system: SYSTEM_PROMPT,
        messages: trimmed
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', response.status, errText);
      return res.status(502).json({ error: 'Upstream AI request failed' });
    }

    const data = await response.json();
    const textBlock = (data.content || []).find(block => block.type === 'text');
    const reply = textBlock ? textBlock.text : "Sorry, I couldn't generate a reply just now.";

    res.json({ reply });
  } catch (err) {
    console.error('Agent chat error:', err);
    res.status(500).json({ error: 'Something went wrong handling your message' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`DINASTY server running on http://localhost:${PORT}`);
});
