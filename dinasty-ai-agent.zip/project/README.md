# DINASTY — AI Agent backend

This adds a real, Claude-powered "AI Agent" to the DINASTY site. The
frontend (`public/index.html`, `public/style.css`, `public/script.js`) is
unchanged in everything else — the AI Agent button opens a chat panel that
now talks to a small server instead of a fixed script.

## Why a server is needed

The AI Agent calls the Anthropic API, which requires a secret API key.
That key can never live in `script.js` or any other file the browser
downloads — anyone could open dev tools, copy it, and run up your bill.
So `server.js` holds the key and is the only thing that talks to
Anthropic; the browser only ever talks to *your* server.

## Setup

1. Install Node.js 18 or later if you don't have it.
2. In this folder, install dependencies:
   ```
   npm install
   ```
3. Copy `.env.example` to `.env` and paste in your real API key:
   ```
   cp .env.example .env
   ```
   Get a key from the Anthropic Console: https://console.anthropic.com/
4. Start the server:
   ```
   npm start
   ```
5. Open **http://localhost:3000** in your browser — not the `index.html`
   file directly. The server serves the frontend *and* answers the
   `/api/agent-chat` requests the AI Agent makes, so both need to come
   from the same place.

## How it works

- `public/script.js` posts the conversation so far to `/api/agent-chat`.
- `server.js` adds a system prompt describing DINASTY's real features
  (goal picker, reviews, community, quotes), forwards the conversation
  to Claude, and returns just the reply text.
- The agent answers whatever is actually asked — it isn't limited to
  DINASTY topics — but it uses its knowledge of the real UI whenever
  that's relevant, and won't invent features that don't exist.
- It runs on `claude-opus-5`, Anthropic's more capable tier, for
  better reasoning on open-ended or nuanced questions. That's slower
  and costs more per message than a lighter model — if you'd rather
  optimize for speed/cost instead, change `MODEL` in `server.js` to
  `'claude-sonnet-5'`.

## Deploying

Any Node hosting works (Render, Railway, Fly.io, a VPS, etc.) — set
`ANTHROPIC_API_KEY` as an environment variable there (don't commit your
`.env` file), and point your domain at the server. It already serves the
static frontend, so nothing else needs separate hosting.

## Files

```
server.js         — Express server + the /api/agent-chat proxy
package.json       — dependencies (express, dotenv)
.env.example        — copy to .env and add your API key
public/
  index.html       — the DINASTY site
  style.css
  script.js
```
